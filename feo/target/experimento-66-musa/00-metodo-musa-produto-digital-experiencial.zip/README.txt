Metodo MUSA - Produto Digital Experiencial

Comece pelo arquivo 01-experiencia-guiada/index.html.
Use a experiencia para fazer o diagnostico, cumprir as missoes de 7 dias e marcar seu progresso.
Depois consulte 02-ebook-principal.pdf para aprofundar o metodo.
Use 03-plano-checklists-e-templates.csv para preencher seu plano.
As imagens da pasta imagens/ sao figuras de apoio da experiencia e do e-book.

Arquivos do pacote:
01-experiencia-guiada/index.html
02-ebook-principal.pdf
03-plano-checklists-e-templates.csv
imagens/vis-01.png
imagens/vis-02.png
imagens/vis-03.png
imagens/vis-04.png

Promessa: Monte em 7 dias uma presença mais elegante, marcante e coerente sem depender de luxo caro, compras impulsivas ou transformação radical.
