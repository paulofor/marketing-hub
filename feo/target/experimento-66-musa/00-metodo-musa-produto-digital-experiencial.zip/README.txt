Metodo MUSA - Produto Digital Experiencial

Comece pelo arquivo 01-experiencia-guiada/index.html.
Use a experiencia para fazer o diagnostico, cumprir as missoes de 7 dias e marcar seu progresso.
Depois consulte 02-ebook-principal.pdf para aprofundar o metodo.
Use 03-plano-checklists-e-templates.csv para preencher seu plano.
As imagens da pasta imagens/ sao figuras de apoio da experiencia e do e-book.

Arquivos do pacote:
01-experiencia-guiada/index.html
02-ebook-principal.pdf
03-plano-checklists-e-templates.csv
imagens/vis-01-capa-editorial-do-e-book-principal.png
imagens/vis-02-infografico-do-plano-de-7-dias.png
imagens/vis-03-mapa-visual-de-presenca-elegante.png
imagens/vis-04-antes-e-depois-conceitual-da-aplicacao.png

Promessa: Monte em 7 dias uma presença mais elegante, marcante e coerente sem depender de luxo caro, compras impulsivas ou transformação radical.
