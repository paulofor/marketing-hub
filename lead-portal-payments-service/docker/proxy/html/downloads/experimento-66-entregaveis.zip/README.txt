Entregaveis do experimento
==========================

Experimento: MUSA-H001-E004
ID: 66
Nicho: Mulheres urbanas - sofisticacao acessivel
Hipotese: Oferta low-ticket MUSA valida se mulheres que desejam presença elegante acessível compram um kit prático de transformação em 7 dias por R$47.

Conteudo do ZIP:
- landing-page-deliverables.json: artefato final do GeraLanding quando existir.
- entregaveis/: versoes HTML prontas para leitura dos entregaveis aprovados.
- pacotes/: versoes HTML prontas para revisao dos pacotes vinculados.
- feo/: artefatos finais premium fabricados pela FEO quando a montagem ja concluiu.

Totais:
- Entregaveis do nicho: 31
- Pacotes do experimento: 2
