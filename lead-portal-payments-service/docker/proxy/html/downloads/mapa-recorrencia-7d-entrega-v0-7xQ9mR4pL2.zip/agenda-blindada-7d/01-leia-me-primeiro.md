# Leia-me primeiro - Agenda Blindada 7D

Comece preenchendo o arquivo mapa-recorrencia-7d.csv com os atendimentos dos proximos 7 dias.

Sequencia recomendada:
1. Liste cada atendimento com dia, horario, cliente, bairro e servico.
2. Marque o status de confirmacao: confirmado, aguardando resposta, precisa de sinal ou risco.
3. Use as mensagens prontas para confirmar, pedir sinal, reagendar ou oferecer encaixe.
4. Revise o checklist de rotas para reduzir deslocamentos soltos.
5. Ao final de cada dia, atualize o status e registre faltas, atrasos ou oportunidades.
