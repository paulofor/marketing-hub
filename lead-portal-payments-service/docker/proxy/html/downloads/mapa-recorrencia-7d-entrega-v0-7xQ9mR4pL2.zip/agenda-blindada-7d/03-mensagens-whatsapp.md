# Mensagens prontas de WhatsApp

## Confirmacao no dia anterior
Oi, [NOME]. Passando para confirmar nosso horario de amanha, [DIA], as [HORA]. Posso manter reservado para voce?

## Lembrete no dia do atendimento
Oi, [NOME]. Nosso atendimento esta confirmado para hoje as [HORA]. Qualquer imprevisto, me avise com antecedencia para eu reorganizar a rota.

## Pedido educado de sinal
Para deixar seu horario reservado com seguranca, trabalho com sinal de R$ [VALOR]. Assim que voce enviar, eu confirmo seu atendimento na agenda.

## Reagendamento
Sem problema, [NOME]. Para remarcar, tenho estas opcoes: [OPCAO 1], [OPCAO 2] ou [OPCAO 3]. Qual fica melhor para voce?

## Oferta de encaixe
Oi, [NOME]. Abriu um horario em [DIA] as [HORA] na sua regiao. Quer aproveitar esse encaixe?
