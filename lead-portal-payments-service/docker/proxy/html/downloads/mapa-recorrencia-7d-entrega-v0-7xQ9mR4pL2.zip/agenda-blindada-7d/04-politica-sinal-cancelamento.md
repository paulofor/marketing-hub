# Politica simples de sinal, cancelamento e reagendamento

- O horario fica reservado apos confirmacao da cliente.
- Para atendimentos com maior duracao ou deslocamento, solicitar sinal antes de bloquear a agenda.
- Reagendamentos devem ser avisados com antecedencia sempre que possivel.
- Cancelamentos em cima da hora podem exigir novo sinal para remarcar.
- A regra deve ser explicada antes do agendamento, em tom educado e direto.

Modelo curto:
Para organizar melhor minha rota e garantir seu horario, trabalho com confirmacao antecipada e sinal nos atendimentos com maior deslocamento. Se precisar remarcar, me avise antes para eu conseguir ajustar a agenda.
