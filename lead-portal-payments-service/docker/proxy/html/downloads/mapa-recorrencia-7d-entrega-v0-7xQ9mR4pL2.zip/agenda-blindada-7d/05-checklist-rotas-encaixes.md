# Checklist de rotas e encaixes

- Agrupe atendimentos por bairro ou regioes proximas.
- Evite deixar um unico atendimento distante sem confirmacao forte.
- Identifique horarios vagos entre atendimentos e ofereca encaixe para clientes proximas.
- Confirme primeiro os atendimentos com maior deslocamento.
- Mantenha uma lista de clientes que aceitam encaixe rapido.
- Revise a rota na noite anterior e no inicio do dia.
